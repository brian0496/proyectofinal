# Send-Flash
Repositorio dedicado para trabajo final de carrera.

Este proyecto solicita la creación de software para empresa de que se encarga de realizar
envíos, cuyo entorno de trabajo sea a través de app y/o web, con la intención de crear dos 
aplicaciones móviles uno para envíos (usuario), otro para el conductor (cadete); con una plataforma
web en la cual se encuentre toda la información del software.

El proyecto de las apps se desarrollará en JAVA.

#### Autores
* Corvalán, Brian (https://github.com/brian0496)
* Donato, Horacio (https://github.com/hdonato1)
* Suarez, Ezequiel (https://github.com/ezequielsuarez)
