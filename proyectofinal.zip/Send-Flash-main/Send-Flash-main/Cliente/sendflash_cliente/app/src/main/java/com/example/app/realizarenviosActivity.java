package com.example.app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Arrays;
import java.util.List;

public class realizarenviosActivity extends AppCompatActivity {

    EditText tipo_paquete;
    EditText dimensiones;
    EditText nombre_destinatario;
    EditText direccion_destino;
    EditText barrio_destino;
    TextView a_pagar;
    Button proceder_pago;
    Button consultar_precio;


    String precio_pagar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_realizarenvios);

        tipo_paquete = findViewById(R.id.tipo_paquete);
        dimensiones = findViewById(R.id.dimensiones);
        nombre_destinatario = findViewById(R.id.nombre_destinatario);
        direccion_destino = findViewById(R.id.direccion_destino);
        barrio_destino = findViewById(R.id.barrio_destino);

        a_pagar = findViewById(R.id.a_pagar);

        proceder_pago = findViewById(R.id.proceder_pago);
        consultar_precio = findViewById(R.id.consultar_precio);


        consultar_precio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String barrio = barrio_destino.getText().toString();
                String paquete = tipo_paquete.getText().toString();

                List<String> lista2 = Arrays.asList("saavedra", "nuñes", "coghian", "belgrano", "villa urquiza", "parque chas", "villa ortuzar", "chacarita", "palermo", "villa crespo");
                List<String> lista1 = Arrays.asList("recoleta", "retiro", "san nicolas", "montserrat", "puerto madero", "san telmo", "constitucion", "la boca", "barracas");
                List<String> lista3 = Arrays.asList("almagro", "balvanera", "caballito", "san cristobal", "boedo", "parque patricios", "nueva pompeya", "parque chabcabuco", "flores");
                List<String> lista4 = Arrays.asList("villa pueyrredon", "agronomia", "paternal", "villa del parque", "villa devoto", "villa general mitre", "villa santa rita", "monte castro", "villa real", "floresta", "velez sarflield", "villa luro", "versalies", "liniers", "mataderos", "parque avellaneda", "villa soldati", "villa lugano", "villa riachuelo");

                int preciobarrio = 0;
                int preciotipo = 0;

                if (lista1.contains(barrio)) {
                    preciobarrio = 500;
                } else if (lista2.contains(barrio)) {
                    preciobarrio = 400;
                } else if (lista3.contains(barrio)) {
                    preciobarrio = 300;
                } else if (lista4.contains(barrio)) {
                    preciobarrio = 200;
                }

                if (paquete == "sobre") {
                    preciotipo = 250;
                } else {
                    preciotipo = 350;
                }

                int precio_total = preciobarrio + preciotipo;
                String precio_total_s = Integer.toString(precio_total);
                a_pagar.setText(precio_total_s);

                precio_pagar = precio_total_s;
            }
        });
    }


    public void  proceder_pago (View view){
        Intent i = new Intent(this, tarjetaActivity.class);
        startActivity(i);
    }
}
