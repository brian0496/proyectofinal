package com.example.app;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.app.modelo.DatosUsuarios;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class formActivity extends AppCompatActivity {

    FirebaseAuth auth;

    private EditText nombre;
    private EditText apellido;
    private EditText domicilio;
    private EditText fecha_nacimineto;
    private EditText dni;
    private EditText telefono;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form);

        nombre = findViewById(R.id.nombre);
        apellido = findViewById(R.id.apellido);
        domicilio = findViewById(R.id.domicilio);
        fecha_nacimineto = findViewById(R.id.fecha_nacimiento);
        dni = findViewById(R.id.dni);
        telefono = findViewById(R.id.telefono);

        auth = FirebaseAuth.getInstance();
    }

    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference("cliente");

    public void guardarDAtos(View view){
        DatosUsuarios datosUsuarios = new DatosUsuarios();
        if (auth.getCurrentUser()!= null){
            myRef.child(auth.getCurrentUser().getUid()).setValue(datosUsuarios).addOnSuccessListener(new OnSuccessListener<Void>() {
                @Override
                public void onSuccess(Void avoid) {
                    Toast.makeText( formActivity.this, "Se ha guardado correctamente", Toast.LENGTH_SHORT).show();
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText( formActivity.this, "No se ha guardado correctamente", Toast.LENGTH_SHORT).show();
                }
            });
        }

        Intent i = new Intent(getApplicationContext(), homeActivity.class);
        startActivity(i);
    }
}