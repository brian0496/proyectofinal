package com.example.app;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class tarjetaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tarjeta);


    }

    public void pagar(View view){
        Toast.makeText(getApplicationContext(), "Pago realizado.",
                Toast.LENGTH_SHORT).show();
    }
}