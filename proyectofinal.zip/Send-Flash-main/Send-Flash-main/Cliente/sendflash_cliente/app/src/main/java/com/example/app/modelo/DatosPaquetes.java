package com.example.app.modelo;

public class DatosPaquetes {

    public DatosPaquetes(int id_paquete,int id_cliente, int id_cadete, String nombre_destino, String descripcion, String direccion_destino, String barrio_destino ,String dimensiones){
        this.id_paquete = id_paquete;
        this.id_cliente = id_cliente;
        this.id_cadete = id_cadete;
        this.nombre_destino = nombre_destino;
        this.descripcion = descripcion;
        this.direccion_destino = direccion_destino;
        this.barrio_destino = barrio_destino;
        this.dimensiones = dimensiones;
    }

    private int id_paquete;
    private int id_cliente;
    private int id_cadete;
    private String nombre_destino;
    private String descripcion;
    private String direccion_destino;
    private String barrio_destino;
    private String dimensiones;
}


