package com.example.app;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.app.modelo.DatosUsuarios;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Objects;

public class editperfilActivity extends AppCompatActivity {

    FirebaseAuth auth;

    private FirebaseDatabase firebaseDatabase;
    private DatabaseReference mDatabase;

    EditText editnombre;
    EditText editapellido;
    EditText editdomicilio;
    EditText editdni;
    EditText editFnacimiento;
    EditText editTelefono;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editperfil);


        editnombre = findViewById(R.id.editnombre);
        editapellido = findViewById(R.id.editapellido);
        editdomicilio = findViewById(R.id.editdomicilio);
        editdni = findViewById(R.id.editdni);
        editFnacimiento = findViewById(R.id.editFnacimiento);
        editTelefono = findViewById(R.id.edittelefono);

        auth = FirebaseAuth.getInstance();

        mDatabase = FirebaseDatabase.getInstance().getReference().child("cliente");
        mDatabase.child(auth.getCurrentUser().getUid()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()){

                    String nombre = dataSnapshot.child("nombre").getValue().toString();
                    editnombre.setText(nombre);

                    String apellido = dataSnapshot.child("apellido").getValue().toString();
                    editapellido.setText(apellido);

                    String domicilio = dataSnapshot.child("domicilio").getValue().toString();
                    editdomicilio.setText(domicilio);

                    String dni = dataSnapshot.child("dni").getValue().toString();
                    editdni.setText(dni);

                    String fecha_nacimineto = dataSnapshot.child("fecha_nacimiento").getValue().toString();
                    editFnacimiento.setText(fecha_nacimineto);

                    String telefono = dataSnapshot.child("telefono").getValue().toString();
                    editTelefono.setText(telefono);

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

    public void modificar(View view){

        DatosUsuarios datosUsuarios = new DatosUsuarios();
        datosUsuarios.setNombre(editnombre.getText().toString());
        datosUsuarios.setApellido(editapellido.getText().toString());
        datosUsuarios.setDomicilio(editdomicilio.getText().toString());
        datosUsuarios.setDni(editdni.getText().toString());
        datosUsuarios.setFecha_nacimiento(editFnacimiento.getText().toString());
        datosUsuarios.setTelefono(editTelefono.getText().toString());

        mDatabase.child(auth.getCurrentUser().getUid()).setValue(datosUsuarios);
        Toast.makeText( editperfilActivity.this, "actualizado", Toast.LENGTH_SHORT).show();

        Intent i = new Intent(getApplicationContext(), perfilActivity.class);
        startActivity(i);
    }
}