package com.example.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.app.modelo.DatosUsuarios;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class perfilActivity extends AppCompatActivity {

    FirebaseAuth auth;

    private DatabaseReference mDatabase;

    TextView view_nombre;
    TextView viewapellido;
    TextView viewdomicilio;
    TextView viewdni;
    TextView viewfechanacimiento;
    TextView viewtelefono;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil);

        view_nombre = (TextView) findViewById(R.id.view_nombre);
        viewapellido = findViewById(R.id.viewapellido);
        viewdomicilio = findViewById(R.id.viewdomicilio);
        viewdni = findViewById(R.id.viewdni);
        viewfechanacimiento = findViewById(R.id.viewfechanacimiento);
        viewtelefono =findViewById(R.id.viewtelefono);

        auth = FirebaseAuth.getInstance();

        String id ;
        id = auth.getCurrentUser().getUid();


        mDatabase = FirebaseDatabase.getInstance().getReference().child("cliente");
        mDatabase.child(id).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()){

                    String nombre = dataSnapshot.child("nombre").getValue().toString();
                    view_nombre.setText(nombre);

                    String apellido = dataSnapshot.child("apellido").getValue().toString();
                    viewapellido.setText(apellido);

                    String domicilio = dataSnapshot.child("domicilio").getValue().toString();
                    viewdomicilio.setText(domicilio);

                    String dni = dataSnapshot.child("dni").getValue().toString();
                    viewdni.setText(dni);

                    String fecha_nacimineto = dataSnapshot.child("fecha_nacimiento").getValue().toString();
                    viewfechanacimiento.setText(fecha_nacimineto);

                    String telefono = dataSnapshot.child("telefono").getValue().toString();
                    viewtelefono.setText(telefono);

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }


    public void iraeditar(View view){
        Intent i = new Intent(getApplicationContext(), editperfilActivity.class);
        startActivity(i);
    }
}