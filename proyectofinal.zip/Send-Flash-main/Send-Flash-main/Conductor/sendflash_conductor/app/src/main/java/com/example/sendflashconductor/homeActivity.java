package com.example.sendflashconductor;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class homeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
    }


    public void irpaquetesdisponibles(View view){
        Intent i = new Intent(this, paquetedisponiblesActivity.class);
        startActivity(i);
    }


    public void irperfil(View view){
        Intent i = new Intent(this, perfilActivity.class);
        startActivity(i);
    }
}