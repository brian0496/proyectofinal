package com.example.sendflashconductor;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class paquetedisponiblesActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_paquetedisponibles);
    }
}