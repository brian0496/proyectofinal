package com.example.sendflashconductor.modelo;

public class DatosUsuarios {


    public String getNombre() {return nombre;}
    public void setNombre(String nombre){this.nombre = nombre;}

    public String getApellido() {return apellido;}
    public void setApellido(String apellido) {this.apellido = apellido;}

    public String getDomicilio() {return domicilio;}
    public void setDomicilio(String domicilio) {this.domicilio = domicilio;}

    public String getFecha_nacimiento() {return fecha_nacimiento;}
    public void setFecha_nacimiento(String fecha_nacimiento) {this.fecha_nacimiento = fecha_nacimiento;}

    public String getDni() {return dni;}
    public void setDni(String dni) {this.dni = dni;}

    public String getTelefono() {return telefono;}
    public void setTelefono(String telefono) {this.telefono = telefono;}

    public String getCedula_verde() {return cedula_verde;}
    public void setCedula_verde(String cedula_verde) {this.cedula_verde = cedula_verde;}

    public String getLicencia() {return licencia;}
    public void setLicencia(String licencia) {this.licencia = licencia;}

    public DatosUsuarios() {
        this.nombre = nombre;
        this.apellido = apellido;
        this.domicilio = domicilio;
        this.fecha_nacimiento = fecha_nacimiento;
        this.dni = dni;
        this.telefono = telefono;
        this.cedula_verde = cedula_verde;
        this.licencia = licencia;
    }

    private String nombre;
    private String apellido;
    private String domicilio;
    private String fecha_nacimiento;
    private String dni;
    private String telefono;
    private String cedula_verde;
    private String licencia;

}
