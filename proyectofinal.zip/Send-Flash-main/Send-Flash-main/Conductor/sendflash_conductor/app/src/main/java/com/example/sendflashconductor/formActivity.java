package com.example.sendflashconductor;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;


import com.example.sendflashconductor.modelo.DatosUsuarios;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class formActivity extends AppCompatActivity {

    private EditText nombre;
    private EditText apellido;
    private EditText domicilio;
    private EditText fecha_nacimineto;
    private EditText dni;
    private EditText telefono;
    private EditText cedula_verde;
    private EditText licencia;

    private FirebaseDatabase database;
    private DatabaseReference myRef;

    FirebaseAuth auth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form);

        nombre = findViewById(R.id.nombre);
        apellido = findViewById(R.id.apellido);
        domicilio = findViewById(R.id.domicilio);
        fecha_nacimineto = findViewById(R.id.fecha_nacimiento);
        dni = findViewById(R.id.dni);
        telefono = findViewById(R.id.telefono);
        cedula_verde = findViewById(R.id.cedula_verde);
        licencia = findViewById(R.id.licencia);

        auth = FirebaseAuth.getInstance();

        database = FirebaseDatabase.getInstance();
        myRef = database.getReference("cadete");
    }

    public void guardarDAtos(View view){
        DatosUsuarios datosUsuarios = new DatosUsuarios();
        if (auth.getCurrentUser()!= null){
            myRef.child(auth.getCurrentUser().getUid()).setValue(datosUsuarios).addOnSuccessListener(new OnSuccessListener<Void>() {
                @Override
                public void onSuccess(Void avoid) {
                    Toast.makeText( formActivity.this, "Se ha guardado correctamente", Toast.LENGTH_SHORT).show();
                    System.out.println(myRef);
                    System.out.println(auth.getCurrentUser().getUid());
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText( formActivity.this, "No se ha guardado correctamente", Toast.LENGTH_SHORT).show();
                }
            });
        }

        Intent i = new Intent(getApplicationContext(), homeActivity.class);
        startActivity(i);
    }

}